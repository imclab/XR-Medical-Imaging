Old DNA modelling set Version 1. 

This DNA modelling set was the first version originally posted 
on thingeyverse back in March 2015. I recommmend using the current 
version, as this original version had some weaknesses in the backbone 
piece which meant the joining pins could easily shear off. 

Good luck! 
MK   




DNA model stand version 1. 

This stand is designed to hold the folding DNA model kit:
http://www.thingiverse.com/thing:714312

Hopefully the assembly is straight forward. (please refer 
to the figure DNA_stand_pic.jpg)

Once all the parts are printed, insert the Stand arm into the Stand 
base. You may wish to glue this together. 

Next, joint elbow part one and elbow part 2 together by aligning the 
holes and insertin the elbow pin. There should be enough play in this 
to allow the elbow to move stiffly. 

Now insert the elbow into the top of the Stand arm piece.  At the other 
end of the elbow insert the DNA grip piece. This should fit snuggly, 
but also be able to rotate. The DNA grip is designed to slot into the 
minor groove of the DNA helix while the 'tongue' slips between base 
pairs to hold the double helix in place. 

Hopefully this is reasonable secure.  -I am hoping to make better 
DNA grip pieces eventually so it is designed to be interchangeable. 

Good luck! 

Mike Kuiper
March 2016.  
